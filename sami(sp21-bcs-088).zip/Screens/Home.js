import {View,Text} from "react-native";
import { useEffect,useState } from "react";
import { DrawerNavigator } from "../Components/DrawerNavigator";
import { addDocs } from "../Components/docADD";
import { db } from "../firebase";


export default function HomeScreen(){
    // q3 final paper
    useEffect(() => {
        addDocs("Home");
      } , [])

      // part 2 question 4
     const [orientation, setOrientation] = useState('sideMenu'); 

     useEffect(() => {
        // Set up Firestore listener to listen for changes in the configuration value
        
        const configRef = db.collection('appConfig').doc('config');
    
        const unsubscribe = configRef.onSnapshot(snapshot => {
          const newOrientation = snapshot.data().orientation;
          setOrientation(newOrientation);
        });

        return () => {
            unsubscribe();
          };
        }, []);

    return(
        <View>
             {orientation === 'sideMenu' ? (
             <View style={{flex:1}}>
             <DrawerNavigator/>
             </View>
             ) : (
             <View style={{flex:1}}>
              <BottomNavigator/>
              </View>
             )}
            
        </View>
    )
}