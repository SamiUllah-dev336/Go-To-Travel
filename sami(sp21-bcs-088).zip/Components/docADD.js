import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

export const addDocs = async(screen)=>{

    const docRef = doc(db, "Track", "5");
    await updateDoc(docRef, {
      screen: screen 
    });
}