import {View,Text} from "react-native";


export default function HelpScreen(){
    return(
        <View>
            <Text>Help screen</Text>
        </View>
    )
}