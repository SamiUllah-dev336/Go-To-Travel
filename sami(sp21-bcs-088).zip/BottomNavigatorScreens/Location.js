import {View,Text} from "react-native";


export default function LocationScreen(){
    return(
        <View>
            <Text>Location screen</Text>
        </View>
    )
}