import {View,Text,StyleSheet,FlatList,Image,Platform} from "react-native";
import { db } from "../firebase";
import { useState,useEffect } from "react";
import { addDocs } from "../Components/docADD";

//import firestore from '@react-native-firebase/firestore';

//import {collection,add, addDoc} from 'firebase/firestore';
import { getDatabase, ref, onValue, set, update } from "firebase/database";

import {
    firestore,
    getFirestore,
    collection,
    getDocs,
    addDoc,
    onSnapshot,
    doc,
    deleteDoc,
    updateDoc,
    query,
    where,
  } from "firebase/firestore";



const collecArray=(collec)=>{
    const snapshot = collection(db, collec);   // or getFirestore() replace by db
    //console.log(ref);
    const arr=new Array;
    const q = query(snapshot,ref)           // it can work without ref
    onSnapshot(q, snapshot=>{
      // console.log('Fetched', snapshot.docs)
      snapshot.docs.forEach(doc=>{
        
        console.log(doc.id,doc.data())
        arr.push(doc.data());
      })
    }
    )
    return arr;
  }

export default function TicketChangeScreen(){
      
     // q3 final paper
      useEffect(() => {
        addDocs("TicketChange");
      } , [])
 
      // question no 1 final paper

      useEffect(() => {
        const addDoc = async()=>{
    
          const docRef = doc(db, "device", "10");
          await updateDoc(docRef, {
            name: Platform.OS
          });
        }
    
        addDoc();
    
      } , []);
  
     // question no 2 final paper data from firestore
    const num=2;
    const [PopularFood , setPopularFood] = useState(collecArray('popularFood')); 
    return(

        <View>
            <Text style={{textAlign:"center",marginBottom:20}}>Ticket Change screen</Text>

            
            <FlatList
            data={PopularFood}
            keyExtractor={item=>item.key}
            horizontal={true}
            renderItem={({item})=>(
            <View style={styles.mainSeller}>
              {/* burger image */}
            <View style={{flex:0.3,alignItems:'center',justifyContent:'center'}}>
            <Image source={{uri:item.burgerImage}} style={{height:80,width:80}}/>
            </View>
            
            {/* burger name views */}
            <View style={{
                          flex:0.5,
                          
                          }}>
            
            <View style={{flex:0.5,
                          
                          justifyContent:'flex-end'}}>
            <Text style={{
                          fontSize:15,
                          marginLeft:10,
                          fontWeight:'bold'
                          }}>
            {item.burgerName}
            </Text>
            </View>
            
            <View style={{flex:0.5,
                          
                          justifyContent:'flex-start'}}>
            <Text style={{
                          fontSize:15,
                          marginLeft:10,
                          
                          }}>
            {item.price}
            </Text>
            </View>
            </View>
            
            {/* rating views */}
            <View style={{flex:0.2}}>
            {/* heart */}
            <View style={{flex:0.5,alignItems:'center',justifyContent:'flex-end'}}>
            {/* <Icon name={"heart-o"} size={20} color={"red"}/> */}
            </View>
            
            <View style={{flex:0.5,flexDirection:'row'}}>
            {/* rating */}
            
            <View style={{flex:0.4,alignItems:'center'}}>
            <Image source={{uri:item.rating}} style={{height:20,width:20,marginLeft:10}}/>
            </View>
            
            <View style={{flex:0.6}}>
            <Text>{item.ratingPoint}</Text>
            </View> 
            
        
            </View> 
            
            </View>
            
            
            </View>
            )
            } 
            />
            </View>
    )
}


const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      backgroundColor: '#FAF9F6',
      padding: 5,
    },
    outerSearchBar:{
      flex:0.25,
      marginBottom:10
    },
    searchView:{
      flex:0.5,
      marginBottom:10
    },
    searchName:{
      fontSize:20,
      fontWeight:'bold',
      marginBottom:10,
      marginLeft:10
    },
    outerSearchInput:{
      flexDirection:'row',
      backgroundColor:'white',
      width:'80%',
      marginLeft:10,
      marginRight:10,
      borderRadius:10,
    },
    searchIcon:{
      marginTop:10,
      marginLeft:5
    },
    searchTextInput:{
      height:50,
      width:220,
      alignItems:"center",
      justifyContent:"center",
      marginLeft:10,
    },
    slider:{
      marginLeft:40,
      marginTop:5,
      backgroundColor:'red',
      borderRadius:5
    },
    header:{
      flex:0.3,
      justifyContent:'flex-end'
    },
    outerName:{
      marginBottom:3,
      flex:0.2,
      justifyContent:'flex-end'
    },
    name:{
      fontWeight:'bold',
      fontSize:15,
      marginRight:10,
      marginLeft:10
    },
    mainCategory:{
      flex:1,
      flexDirection:"row",
      backgroundColor:"white",
      marginTop:10,
      marginBottom:10,
      marginLeft:10,
      marginright:10,
      padding:10,
      borderRadius:5,
      height:50,
      width:140,
      alignItems:'center',
      justifyContent:'center',
    },
  
    main:{
      backgroundColor:'white',
      marginRight:10,
      padding:5,
      marginBottom:10,
    },
    rating:{
      flexDirection:"row",
    },
    image:{
      alignItems:"center",
      marginBottom:20,
      
    },
    imagName:{
      alignItems:"center",
      justifyContent:"center",
    },
    mainSeller:{
      flex:1,
      height:80,
      width:340,
      marginTop:10,
      marginLeft:10,
      marginRight:10,
      borderRadius:10,
      backgroundColor:'white',
      flexDirection:'row',
    },
  
  });