import {View,Text} from "react-native";
import { useEffect } from "react";
import { BottomNavigator } from "../Components/BottomDrawer";
import { addDocs } from "../Components/docADD";

export default function ProfileScreen(){
    // q3 final
    useEffect(() => {
        addDocs("Profile");
      } , [])

    return(
        <View style={{flex:1}}>
            <BottomNavigator/>
        </View>
    )
}